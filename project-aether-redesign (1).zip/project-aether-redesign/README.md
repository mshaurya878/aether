# Project Aether — Navbar-first portfolio

A static, responsive portfolio built with semantic HTML, CSS, and vanilla JavaScript. No build step or package installation is required.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser. For best compatibility with PDF links, run a local static server from this folder:
   - Python: `python -m http.server 8000`
   - Then visit `http://localhost:8000`.

## Update your information
Edit `data.js`. Replace `YOUR_NAME`, `YOUR_BIO`, `YOUR_FOCUS`, skill placeholders, education placeholders, project descriptions, email and profile links with verified details.

Repeated sections are generated from arrays in `data.js`. The HTML layout stays separate from styling (`styles.css`) and behavior (`script.js`).

## Certificate source
`assets/certificates-source.pdf` is the supplied 10-page PDF. Certificate cards link to the relevant source PDF pages. Duplicate completion/assessment documents are grouped into one credential. The inconsistent Adobe assessment page is intentionally not included.

## Important implementation notes
- No backend or contact-form submission is claimed. Configured email uses a `mailto:` link.
- No analytics or visitor statistics are fabricated.
- GitHub and external profile links remain placeholders until configured.
- The Google Fonts stylesheet requires internet access; system font fallbacks are provided.
- No deployment has been performed.

## Quick checks
- Check all navigation anchors and the mobile menu.
- Test at narrow mobile and desktop widths.
- Verify the certificate PDF opens in your browser.
- Replace placeholders before publishing.
