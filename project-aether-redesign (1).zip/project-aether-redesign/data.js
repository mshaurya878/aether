/*
  EDITABLE PORTFOLIO CONTENT
  Replace placeholder strings and arrays with your own verified details.
  Do not add private credentials or API keys here.
*/
window.PORTFOLIO_DATA = {
  name: "YOUR_NAME",
  focus: "YOUR_FOCUS",
  bio: "YOUR_BIO",
  githubUrl: "",
  email: "YOUR_EMAIL",
  links: {
    linkedin: "",
    github: ""
  },
  skills: [
    { category: "Programming", items: ["YOUR_SKILLS"] },
    { category: "Web development", items: ["YOUR_WEB_SKILLS"] },
    { category: "Tools & platforms", items: ["YOUR_TOOLS"] }
  ],
  education: [
    { period: "YOUR_DATES", title: "YOUR_DEGREE", institution: "YOUR_INSTITUTION", detail: "Add your verified education details here." }
  ],
  projects: [
    { title: "Project Aether", description: "A personal portfolio focused on a clear information hierarchy, accessible navigation, and maintainable front-end code.", technologies: ["HTML", "CSS", "JavaScript"], url: "" },
    { title: "GraamSetu", description: "YOUR_PROJECT_DESCRIPTION", technologies: ["YOUR_TECH_STACK"], url: "" },
    { title: "YOUR_PROJECT", description: "YOUR_PROJECT_DESCRIPTION", technologies: ["YOUR_TECH_STACK"], url: "" }
  ],
  certificates: [
    { title: "AWS Cloud Practitioner Essentials", issuer: "FutureSkills Prime / NASSCOM IT-ITeS SSC", date: "13 Oct 2026", detail: "Gold category assessment certificate.", pages: [1], label: "Gold assessment" },
    { title: "Prompt Engineering and ChatGPT", issuer: "FutureSkills Prime / NASSCOM IT-ITeS SSC", date: "01–09 Oct 2026", detail: "Completion certificate and separate Gold assessment certificate for the same programme.", pages: [2, 4], label: "Completion + Gold assessment" },
    { title: "Adobe Essentials of Generative AI Content Creation", issuer: "Adobe / NASSCOM IT-ITeS SSC", date: "12 Oct 2026", detail: "Completion/participation certificate. A separate assessment document has an inconsistent candidate name and is intentionally excluded.", pages: [3], label: "Completion certificate" },
    { title: "Fueling Data Intelligence in Modern DataOps", issuer: "FutureSkills Prime / NASSCOM IT-ITeS SSC", date: "13 Oct 2026", detail: "Gold category assessment certificate.", pages: [5], label: "Gold assessment" },
    { title: "Full Stack Development with MERN", issuer: "thingQbator / Nasscom Foundation", date: "Date not shown on certificate", detail: "Certificate of Excellence for completion of the programme.", pages: [7], label: "Certificate of Excellence" },
    { title: "Data Science & Machine Learning Fundamentals", issuer: "GUVI / HCL", date: "24 Apr 2026", detail: "Webinar participation certificate.", pages: [8], label: "Webinar participation" },
    { title: "Building a Chatbot Using Python", issuer: "GUVI / HCL", date: "10 Jun 2026", detail: "Certificate of completion.", pages: [9], label: "Course completion" },
    { title: "Future Ready Full Stack Developer", issuer: "GUVI / HCL", date: "11 Jun 2026", detail: "Workshop participation certificate.", pages: [10], label: "Workshop participation" }
  ]
};
