const data = window.PORTFOLIO_DATA;

function createElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function renderSkills() {
  const container = document.querySelector("#skills-grid");
  data.skills.forEach((group, index) => {
    const card = createElement("article", "skill-card");
    card.append(createElement("span", "card-index", String(index + 1).padStart(2, "0")));
    card.append(createElement("h3", "", group.category));
    const tags = createElement("div", "tag-list");
    group.items.forEach((item) => tags.append(createElement("span", "tag", item)));
    card.append(tags);
    container.append(card);
  });
}

function renderEducation() {
  const container = document.querySelector("#education-list");
  data.education.forEach((item) => {
    const row = createElement("article", "education-item");
    row.append(createElement("div", "education-date", item.period));
    const content = createElement("div", "education-content");
    content.append(createElement("h3", "", item.title));
    content.append(createElement("p", "", item.institution));
    content.append(createElement("p", "", item.detail));
    row.append(content);
    container.append(row);
  });
}

function renderProjects() {
  const container = document.querySelector("#projects-grid");
  data.projects.forEach((project, index) => {
    const card = createElement("article", "project-card");
    const top = createElement("div", "project-top");
    top.append(createElement("span", "", `PROJECT / ${String(index + 1).padStart(2, "0")}`));
    top.append(createElement("span", "project-symbol", "↗"));
    card.append(top);
    card.append(createElement("h3", "", project.title));
    card.append(createElement("p", "", project.description));
    const tags = createElement("div", "tag-list");
    project.technologies.forEach((technology) => tags.append(createElement("span", "tag", technology)));
    card.append(tags);
    if (isHttpUrl(project.url)) {
      const link = createElement("a", "certificate-link", "View project ↗");
      link.href = project.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      card.append(link);
    }
    container.append(card);
  });
}

function isHttpUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function renderCertificates() {
  const container = document.querySelector("#certificates-grid");
  data.certificates.forEach((certificate, index) => {
    const card = createElement("article", "certificate-card");
    const top = createElement("div", "certificate-card-top");
    top.append(createElement("span", "certificate-icon", "✳"));
    top.append(createElement("span", "credential-type", String(index + 1).padStart(2, "0") + " / CREDENTIAL"));
    card.append(top);
    card.append(createElement("h3", "", certificate.title));
    card.append(createElement("p", "", certificate.detail));
    const meta = createElement("div", "certificate-meta");
    meta.append(createElement("span", "", certificate.issuer));
    meta.append(createElement("span", "", "· " + certificate.date));
    card.append(meta);
    card.append(createElement("span", "credential-type", certificate.label));
    certificate.pages.forEach((page) => {
      const link = createElement("a", "certificate-link", certificate.pages.length > 1 ? `View source page ${page} ↗` : "View original certificate ↗");
      link.href = `assets/certificates-source.pdf#page=${page}`;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.setAttribute("aria-label", `Open ${certificate.title}, source PDF page ${page}`);
      card.append(link);
    });
    container.append(card);
  });
}

function renderContact() {
  const container = document.querySelector("#contact-links");
  const entries = [];
  if (data.email && data.email !== "YOUR_EMAIL" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    entries.push({ label: "Email", value: data.email, href: `mailto:${data.email}` });
  }
  if (isHttpUrl(data.links.linkedin)) entries.push({ label: "LinkedIn", value: "Open profile", href: data.links.linkedin });
  if (isHttpUrl(data.links.github)) entries.push({ label: "GitHub", value: "Open profile", href: data.links.github });
  if (entries.length === 0) {
    const placeholder = createElement("p", "muted", "Add a valid email address or profile URL in data.js to activate contact links.");
    container.append(placeholder);
  }
  entries.forEach((entry) => {
    const link = createElement("a", "contact-link");
    link.href = entry.href;
    link.append(createElement("span", "", entry.label));
    link.append(createElement("strong", "", entry.value + " ↗"));
    if (entry.href.startsWith("https://") || entry.href.startsWith("http://")) {
      link.target = "_blank";
      link.rel = "noopener noreferrer";
    }
    container.append(link);
  });
}

function setupNavbar() {
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector("#nav-links");
  const links = [...document.querySelectorAll(".nav-link, .nav-contact")];

  function closeMenu() {
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open navigation menu");
  }

  toggle.addEventListener("click", () => {
    const isOpen = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", String(!isOpen));
    toggle.setAttribute("aria-label", isOpen ? "Open navigation menu" : "Close navigation menu");
    nav.classList.toggle("open", !isOpen);
  });

  links.forEach((link) => link.addEventListener("click", closeMenu));
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeMenu();
      toggle.focus();
    }
  });

  const sections = [...document.querySelectorAll("main section[id]")];
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        document.querySelectorAll(".nav-link").forEach((link) => {
          const active = link.getAttribute("href") === `#${entry.target.id}`;
          link.classList.toggle("active", active);
          if (active) link.setAttribute("aria-current", "location");
          else link.removeAttribute("aria-current");
        });
      });
    }, { rootMargin: "-22% 0px -65% 0px", threshold: 0 });
    sections.forEach((section) => observer.observe(section));
  }
}

function applyProfileData() {
  document.querySelectorAll("[data-content]").forEach((element) => {
    const key = element.dataset.content;
    if (data[key]) element.textContent = data[key];
  });

  const githubLink = document.querySelector("#github-link");
  if (isHttpUrl(data.githubUrl)) {
    githubLink.href = data.githubUrl;
    githubLink.textContent = "Open GitHub profile ↗";
    githubLink.target = "_blank";
    githubLink.rel = "noopener noreferrer";
  } else {
    githubLink.href = "#contact";
    githubLink.textContent = "Add profile URL in data.js";
  }

  document.querySelector("#copyright-year").textContent = `© ${new Date().getFullYear()}`;
}

function initPortfolio() {
  applyProfileData();
  renderSkills();
  renderEducation();
  renderProjects();
  renderCertificates();
  renderContact();
  setupNavbar();
}

initPortfolio();
